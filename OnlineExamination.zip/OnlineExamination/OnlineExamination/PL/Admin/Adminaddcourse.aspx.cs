﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;

namespace OnlineExamination.PL.Admin
{
    public partial class Adminaddcourse : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ACHK"] == null)
            {
                Response.Redirect("~/home.aspx");
            }
            Lbl_msgdisplay.Visible = false;
            if (!IsPostBack)
            {
                Loaddepartment();
            }
        }

        private void Loaddepartment()
        {


                try
                {
                    string query_ddldepartment = "SELECT dept_id,dept_name from tbl_department";
                    con.DBDataAdapterdropdown(query_ddldepartment,ddl_departmentname);    
                    
                }
                catch (Exception ex)
                {
                    // Handle the error
                }
              ddl_departmentname.Items.Insert(0, new ListItem("Select department", "0"));

          }

           

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(ddl_departmentname.SelectedValue) <= 0 )
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please select department";
                }else if (txt_coursename.Text == "" || ddl_departmentname.SelectedValue=="")
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please enter valid details";
                }
                else
                {
                    string query_deptchk = "select count(*) from tbl_course where course_name='" + txt_coursename.Text + "'";
                    int deptchk = con.DBReaderOpen1(query_deptchk);
                    con.DBReaderClose1();
                    if (deptchk == 1)
                    {
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Course name already exists. \nPlease enter new department name";
                    }
                    else
                    {
                        string query_deptinsrt = "insert into tbl_course values('" + txt_coursename.Text + "',"+ddl_departmentname.SelectedValue+")";
                        con.DBCmdOpen(query_deptinsrt);
                        con.DBCmdClose();
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Course Added Successfully";
                        txt_coursename.Text = "";
                    }
                }

            }
            catch
            {
                MessageBox.Show("Contact Admin:Course Insrt error");
            }
            finally
            {

            }
        }
    }
}