﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;

namespace OnlineExamination.PL.Admin
{
    public partial class AdminAddDepartment : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ACHK"] == null)
            {
                Response.Redirect("~/home.aspx");
            }
            Lbl_msgdisplay.Visible = false;
        }

        #region Add department,Checks existing departname,checks invalid entry
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_deptname.Text == "")
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please enter valid department name";                    
                }
                else
                {
                    string query_deptchk = "select count(*) from tbl_department where dept_name='"+txt_deptname.Text+"'";
                    int deptchk = con.DBReaderOpen1(query_deptchk);
                    con.DBReaderClose1();
                    if (deptchk == 1)
                    {
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Depatment name already exists. \nPlease enter new department name";                        
                    }
                    else
                    {
                        string query_deptinsrt = "insert into tbl_department values('" + txt_deptname.Text + "')";
                        con.DBCmdOpen(query_deptinsrt);
                        con.DBCmdClose();
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Department Added Successfully";
                        txt_deptname.Text = "";
                    }
                }

            }
            catch
            {
                MessageBox.Show("Contact Admin:DEPT Insrt error");
            }
            finally
            {

            }
        }
        #endregion

    }
}