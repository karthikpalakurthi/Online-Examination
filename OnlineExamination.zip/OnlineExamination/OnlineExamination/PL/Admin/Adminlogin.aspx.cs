﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;

namespace OnlineExamination.PL.Admin
{
    public partial class Adminlogin : System.Web.UI.Page
    {
        connect con = new connect();
         protected void Page_Load(object sender, EventArgs e)
        {
            Lbl_msgdisplay.Visible = false;
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_username.Text == "" || txt_password.Text == "")
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Invalid Details";

            }
            else
            {
                try
                {  
                    String query = "select count(*) from tbl_admin where admin_username='"+txt_username.Text+"' and admin_password='"+txt_password.Text+"'";
                    int ACHK =  con.DBReaderOpen1(query);
                    con.DBReaderClose1();
                    if (ACHK == 1)
                    {
                        Session["ACHK"] = txt_username.Text;
                        Response.Redirect("~/PL/Admin/Adminhome.aspx");
                    }
                    else
                    {
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Not a valid User";
                    }
                }
                catch { }
                finally { }
            }
        }
    }
}