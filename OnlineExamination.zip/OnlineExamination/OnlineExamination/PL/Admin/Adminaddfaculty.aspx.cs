﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;

namespace OnlineExamination.PL.Admin
{
    public partial class Adminaddfaculty : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ACHK"] == null)
            {
                Response.Redirect("~/home.aspx");
            }
            Lbl_msgdisplay.Visible = false;
            if (!IsPostBack)
            {
                Loaddepartment();
            }
        }

        private void Loaddepartment()
        {


            try
            {
                string query_ddldepartment = "SELECT dept_id,dept_name from tbl_department";
                con.DBDataAdapterdropdown(query_ddldepartment, ddl_departmentname);
            }
            catch (Exception ex)
            {
                // Handle the error
            }
            ddl_departmentname.Items.Insert(0, new ListItem("Select department", "0"));
            ddl_coursename.Items.Insert(0, new ListItem("Select course", "0"));
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(ddl_departmentname.SelectedValue) <= 0)
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please select department";
                }
                else if (int.Parse(ddl_coursename.SelectedValue) <= 0)
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please select course";
                }
                else if (txt_facultyname.Text == "" || ddl_departmentname.SelectedValue == "" || ddl_coursename.SelectedValue == "")
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please enter valid details";
                }
                else
                {
                    string query_dcf_faculty = "select faculty_id from tbl_faculty where faculty_email='" + txt_email.Text + "'";
                    con.DBReaderOpen(query_dcf_faculty);
                    string faculty_id = "";
                    int deptchk = 0;
                    if (con.dr.HasRows == true)
                    {
                        while (con.dr.Read())
                        faculty_id = con.dr.GetValue(0).ToString();
                        deptchk = 1;
                    }
                    con.DBReaderClose();
                    if (deptchk == 1)
                    {
                        string query_deptinsrt = "insert into tbl_dcfd values('" +faculty_id+ "','" + ddl_coursename.SelectedValue + "','"+ddl_departmentname.SelectedValue+"','"+DateTime.Now+"')";
                        con.DBCmdOpen(query_deptinsrt);
                        con.DBCmdClose();
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Faculty registered to "+ddl_coursename.SelectedItem+" Successfully";
                        txt_facultyname.Text = "";
                        txt_email.Text = "";

                       
                    }
                    else
                    {

                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Faculty not registered in the system";
                        
                    }
                }

            }
            catch
            {
                MessageBox.Show("Contact Admin:DCFD Insrt error");
            }
            finally
            {

            }
        }

        protected void ddl_departmentname_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                string query_ddlcoursename = "SELECT course_id,course_name from tbl_course where fk_dept_id="+ddl_departmentname.SelectedValue+"";
                con.DBDataAdapterdropdowncourse(query_ddlcoursename, ddl_coursename);

            }
            catch (Exception ex)
            {
                // Handle the error
            }
            ddl_coursename.Items.Insert(0, new ListItem("Select course", "0"));
        }
    }
}