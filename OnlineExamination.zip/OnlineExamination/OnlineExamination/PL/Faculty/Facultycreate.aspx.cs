﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;
namespace OnlineExamination.PL.Faculty
{
    public partial class Facultycreate : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["femail"] == null)
            {
                Response.Redirect("~/home.aspx");

            }
            lbl_logged.Text = lbl_logged.Text = "Logged in as :</br>" + Session["femail"].ToString();
            lbl_subject.Text = "Course name :</br>" + Session["dcf_subject"].ToString();
        }
    }
}