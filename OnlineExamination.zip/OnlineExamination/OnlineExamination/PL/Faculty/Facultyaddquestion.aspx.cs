﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;
namespace OnlineExamination.PL.Faculty
{
    public partial class Facultyaddquestion : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["femail"] == null)
            {
                Response.Redirect("~/home.aspx");

            }
            if (!IsPostBack)
            {
                Loaddepartment();
            }
            Lbl_msgdisplay.Visible = false;
            
            lbl_logged.Text = lbl_logged.Text = "Logged in as : </br>" + Session["femail"].ToString();
            lbl_subject.Text = "Course name : </br>" + Session["dcf_subject"].ToString();
            qtype_MCQ.Visible = false;
            qtype_MAQ.Visible = false;
            qtype_TF.Visible = false;
        }

        private void Loaddepartment()
        {

            try
            {
                string query_ddl_module = "SELECT module_id,module_name from tbl_module where fk_dcf_id="+Session["dcf_module"].ToString()+"";
                con.DBDataAdapterdropdown_all(query_ddl_module, ddl_module);
                ddl_module.DataTextField = "module_name";
                ddl_module.DataValueField = "module_id";
                ddl_module.DataBind();
                con.DBDataAdapterdropdownclose_all();
            }
            catch (Exception ex)
            {
                // Handle the error
            }
            ddl_module.Items.Insert(0, new ListItem("Select module", "0"));

            ddl_qtype.Items.Insert(0, new ListItem("Select question type", "0"));
            ddl_qtype.Items.Insert(1, new ListItem("Multiple Choice questions", "1"));
            ddl_qtype.Items.Insert(2, new ListItem("Multiple Answer questions", "2"));
            ddl_qtype.Items.Insert(3, new ListItem("True or False", "3"));
        }

        protected void ddl_qtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(int.Parse(ddl_module.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select module";
            }
            else if(int.Parse(ddl_qtype.SelectedValue) == 1)
            {
                qtype_MCQ.Visible = true;
            }
            else if(int.Parse(ddl_qtype.SelectedValue) == 2)
            {
                qtype_MAQ.Visible = true;
            }
            else if(int.Parse(ddl_qtype.SelectedValue) == 3)
            {
                qtype_TF.Visible = true;
            }
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            if (int.Parse(ddl_module.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select module";
            }
            else if (int.Parse(ddl_qtype.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select question type";
            }
            else if(txt_question.Text == "" || txt_option1.Text == "" ||txt_option2.Text == "" ||txt_option3.Text == "" ||txt_option4.Text == "" || txt_answer.Text == "")
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please enter valid details";
            }
            else{
                string query_addmcqinsrt = "insert into tbl_question_bank values('MCQ',"+ddl_module.SelectedValue+",'"+txt_question.Text+"','"+txt_option1.Text+"','"+txt_answer.Text+"','"+txt_option2.Text+"','-','"+txt_option3.Text+"','-','"+txt_option4.Text+"','-')";
                con.DBCmdOpen(query_addmcqinsrt);
                con.DBCmdClose();
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Question added successfully";

                txt_question.Text = "";
                txt_option1.Text = "";
                txt_option2.Text = "";
                txt_option3.Text = "";
                txt_option4.Text = "";
                txt_answer.Text = "";
                qtype_MCQ.Visible = true;
            }
        }

        protected void btn_submit_MAQ_Click(object sender, EventArgs e)
        {
            if (int.Parse(ddl_module.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select module";
            }
            else if (int.Parse(ddl_qtype.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select question type";
            }
            else if (txt_question_MAQ.Text == "" || txt_option1_MAQ.Text == "" || txt_option2_MAQ.Text == "" || txt_option3_MAQ.Text == "" || txt_option4_MAQ.Text == "")
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please enter valid details";
            }
            else
            {
                if (txt_answer_MAQ1.Text == "" && txt_answer_MAQ2.Text == "" && txt_answer_MAQ3.Text == "" && txt_answer_MAQ4.Text == "")
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please enter atleast one correct answer";
                }
                else
                {
                    if (txt_answer_MAQ1.Text == "")
                    {
                        txt_answer_MAQ1.Text = "-";
                    }
                    if (txt_answer_MAQ2.Text == "")
                    {
                        txt_answer_MAQ2.Text = "-";
                    }
                    if (txt_answer_MAQ3.Text == "")
                    {
                        txt_answer_MAQ3.Text = "-";
                    }
                    if (txt_answer_MAQ4.Text == "")
                    {
                        txt_answer_MAQ4.Text = "-";
                    }
                    string query_addmaqinsrt = "insert into tbl_question_bank values('MAQ'," + ddl_module.SelectedValue + ",'" + txt_question_MAQ.Text + "','" + txt_option1_MAQ.Text + "','" + txt_answer_MAQ1.Text + "','" + txt_option2_MAQ.Text + "','" + txt_answer_MAQ2.Text + "','" + txt_option3_MAQ.Text + "','" + txt_answer_MAQ3.Text + "','" + txt_option4_MAQ.Text + "','" + txt_answer_MAQ4.Text + "')";
                    con.DBCmdOpen(query_addmaqinsrt);
                    con.DBCmdClose();
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Question added successfully";

                    txt_question_MAQ.Text = "";
                    txt_option1_MAQ.Text = "";
                    txt_option2_MAQ.Text = "";
                    txt_option3_MAQ.Text = "";
                    txt_option4_MAQ.Text = "";
                    txt_answer_MAQ1.Text = "";
                    txt_answer_MAQ2.Text = "";
                    txt_answer_MAQ3.Text = "";
                    txt_answer_MAQ4.Text = "";
                    qtype_MAQ.Visible = true;
                }
            }
        }

        protected void btn_submit_TF_Click(object sender, EventArgs e)
        {
            if (int.Parse(ddl_module.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select module";
            }
            else if (int.Parse(ddl_qtype.SelectedValue) <= 0)
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please select question type";
            }
            else if (txt_question_TF.Text == "" || txt_option1_TF.Text == "" || txt_option2_TF.Text == "" || txt_answer_TF.Text == "")
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Please enter valid details";
            }
            else
            {
                string query_addTFinsrt = "insert into tbl_question_bank values('TF'," + ddl_module.SelectedValue + ",'" + txt_question_TF.Text + "','" + txt_option1_TF.Text + "','" + txt_answer_TF.Text + "','" + txt_option2_TF.Text + "','-','-','-','-','-')";
                con.DBCmdOpen(query_addTFinsrt);
                con.DBCmdClose();
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Question added successfully";

                txt_question_TF.Text = "";
                txt_option1_TF.Text = "";
                txt_option2_TF.Text = "";
                txt_answer_TF.Text = "";
                qtype_TF.Visible = true;
            }
        }
    }
}