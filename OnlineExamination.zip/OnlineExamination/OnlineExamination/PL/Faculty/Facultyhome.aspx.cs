﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;
namespace OnlineExamination.PL.Faculty
{
    public partial class Facultyhome : System.Web.UI.Page
    {
        connect con = new connect();
        string femail;
        string faculty_id = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["femail"] == null)
            {
                Response.Redirect("~/home.aspx");

            }
            femail = Session["femail"].ToString();
            Session["dcf_module"] = null;
            Session["dcf_subject"] = null;
            if (!IsPostBack)
            {
                FillGrid();
            }
            lbl_logged.Text = "Logged in as :</br>" + femail;
        }
        
        public void FillGrid()
        {
            try
            {
                string query_dcf_faculty = "select faculty_id from tbl_faculty where faculty_email='" + femail + "'";
                con.DBReaderOpen(query_dcf_faculty);
                
                if (con.dr.HasRows == true)
                {
                    while (con.dr.Read())
                        faculty_id = con.dr.GetValue(0).ToString();
                    
                }
                con.DBReaderClose();
                query_dcf_faculty = "";
                Session["faculty_id"] = faculty_id.ToString();
                string query_dcf_grid = "select dcf_id,course_name from tbl_course,tbl_dcfd where course_id = fk_course and fk_faculty =" + faculty_id + "";
                con.DBDataAdapter(query_dcf_grid,"query_dcf_grid");
                con.dt = con.ds.Tables["query_dcf_grid"];
                if (con.dt.Rows.Count > 0)
                {
                    grdcourses.DataSource = con.dt;
                    grdcourses.DataBind();
                }
                else {
                    con.dt.Rows.Add(con.dt.NewRow());
                    grdcourses.DataSource = con.dt;
                    grdcourses.DataBind();

                    int TotalColumns = grdcourses.Rows[0].Cells.Count;
                    grdcourses.Rows[0].Cells.Clear();
                    grdcourses.Rows[0].Cells.Add(new TableCell());
                    grdcourses.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                    grdcourses.Rows[0].Cells[0].Text = "No Record Found";
                }
               
            }
            catch { }
            finally { }
        }

        protected void grdContact_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName.Equals("Action"))
            {
                try
                {
                    string dcf_module_id = null; ;
                    string query_module = "select dcf_id from tbl_dcfd where fk_course = (select distinct course_id from tbl_course where course_name='" + e.CommandArgument.ToString() + "') and fk_faculty = " + Session["faculty_id"].ToString() + "";
                    con.DBReaderOpen(query_module);

                    if (con.dr.HasRows == true)
                    {
                        while (con.dr.Read())
                            dcf_module_id = con.dr.GetValue(0).ToString();

                    }
                    con.DBReaderClose();

                    Session["dcf_subject"] = e.CommandArgument.ToString();
                Session["dcf_module"] = dcf_module_id;
                }
                catch { }
                Response.Redirect("~/PL/Faculty/Facultycreate.aspx");
            }
        }
    }
}