﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;

namespace OnlineExamination.PL.Faculty
{
    public partial class Facultylogin : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            Lbl_msgdisplay.Visible = false;
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_username.Text == "" || txt_password.Text == "")
            {
                Lbl_msgdisplay.Visible = true;
                Lbl_msgdisplay.Text = "Invalid Details";

            }
            else
            {
                try
                {
                    String query = "select count(*) from tbl_faculty where faculty_email='" + txt_username.Text + "' and password='" + txt_password.Text + "'";
                    int FCHK = con.DBReaderOpen1(query);
                    con.DBReaderClose1();
                    if (FCHK == 1)
                    {
                        Session["femail"] = txt_username.Text;
                        Response.Redirect("~/PL/Faculty/Facultyhome.aspx");
                    }
                    else
                    {
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Not a valid User";
                    }
                }
                catch { }
                finally { }
            }
        }
    }
}