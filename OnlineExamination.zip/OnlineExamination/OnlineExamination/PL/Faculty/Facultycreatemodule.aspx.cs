﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;
namespace OnlineExamination.PL.Faculty
{
    public partial class Facultycreatemodule : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["femail"] == null)
            {
                Response.Redirect("~/home.aspx");

            }
            Lbl_msgdisplay.Visible = false;
            if (!IsPostBack)
            {
                FillGrid();
            }
            lbl_logged.Text = lbl_logged.Text = "Logged in as : </br>"+ Session["femail"].ToString();
            lbl_subject.Text = "Course name : </br>" + Session["dcf_subject"].ToString();
        }

        public void FillGrid()
        {
            try
            {
                string query_dcf_grid = "select module_id,module_name from tbl_module where fk_dcf_id =" + Session["dcf_module"].ToString() + "";
                con.DBDataAdapter(query_dcf_grid, "query_dcf_grid");
                con.dt = con.ds.Tables["query_dcf_grid"];
                if (con.dt.Rows.Count > 0)
                {
                    grdcourses.DataSource = con.dt;
                    grdcourses.DataBind();
                }
                else
                {
                    con.dt.Rows.Add(con.dt.NewRow());
                    grdcourses.DataSource = con.dt;
                    grdcourses.DataBind();

                    int TotalColumns = grdcourses.Rows[0].Cells.Count;
                    grdcourses.Rows[0].Cells.Clear();
                    grdcourses.Rows[0].Cells.Add(new TableCell());
                    grdcourses.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                    grdcourses.Rows[0].Cells[0].Text = "No Record Found";
                }

            }
            catch { }
            finally { }
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_module.Text == "")
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please enter valid module name";
                }
                else
                {
                    string query_modulechk = "select count(*) from tbl_module where module_name='" + txt_module.Text + "' and fk_dcf_id = " + Session["dcf_module"].ToString()+ "";
                    int deptchk = con.DBReaderOpen1(query_modulechk);
                    con.DBReaderClose1();
                    if (deptchk == 1)
                    {
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Module name already exists. \nPlease enter new module name";
                    }
                    else
                    {
                        string query_deptinsrt = "insert into tbl_module values('" + txt_module.Text + "'," + Session["dcf_module"].ToString() + ")";
                        con.DBCmdOpen(query_deptinsrt);
                        con.DBCmdClose();
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Module Added Successfully";
                        txt_module.Text = "";
                        FillGrid();
                    }
                }

            }
            catch
            {
                MessageBox.Show("Contact Admin:MODULE Insrt error");
            }
            finally
            {

            }
        }
    }
}