﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineExamination.HELPDATA;
using System.Windows.Forms;

namespace OnlineExamination.PL.Faculty
{
    public partial class FacultyRegister : System.Web.UI.Page
    {
        connect con = new connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            Lbl_msgdisplay.Visible = false;
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {

            try
            {
                if (txt_facultyname.Text == "" || txt_email.Text == "" || txt_password.Text == "" || txt_designation.Text == "" || txt_phone.Text == "" || txt_location.Text == "")
                {
                    Lbl_msgdisplay.Visible = true;
                    Lbl_msgdisplay.Text = "Please enter valid details";
                }
                else
                {
                    string query_deptchk = "select count(*) from tbl_faculty where faculty_email='" + txt_email.Text + "'";
                    int facultychk = con.DBReaderOpen1(query_deptchk);
                    con.DBReaderClose1();
                    if (facultychk == 1)
                    {
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Faculty already registered";
                    }
                    else
                    {
                        string query_facultyinsrt = "insert into tbl_faculty values('" +txt_facultyname.Text+ "','"+txt_designation.Text+"','"+txt_email.Text+"',"+txt_phone.Text+",'"+txt_location.Text+"','"+txt_password.Text+"')";
                        con.DBCmdOpen(query_facultyinsrt);
                        con.DBCmdClose();
                        Lbl_msgdisplay.Visible = true;
                        Lbl_msgdisplay.Text = "Faculty Registered Successfully";
                        txt_facultyname.Text = "";
                        txt_email.Text = "";
                        txt_password.Text = "";
                        txt_designation.Text = "";
                        txt_phone.Text = "";
                        txt_location.Text = "";
                    }
                }

            }
            catch
            {
                MessageBox.Show("Contact Admin:FACL Reg Insrt error");
            }
            finally
            {

            }
        }
    }
}