﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;

namespace OnlineExamination.HELPDATA
{
    public class connect
    {
        public SqlConnection cn;
        public SqlCommand cmd;
        public SqlDataReader dr;
        public SqlDataAdapter da;
        public int x;
        public DataSet ds = new DataSet();
        public DataTable dt = new DataTable();

        public void DBOpen()
        {
            cn = new SqlConnection(ConfigurationManager.AppSettings["connect"]);
            cn.Open();
        }
        public void DBClose()
        {
            cn.Close();
        }



        public void DBCmdOpen(string query)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            cmd.ExecuteNonQuery();
        }
        public void DBCmdClose()
        {
            cmd = null;
            cn.Close();
        }



        public void DBReaderOpen(string query)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            dr = cmd.ExecuteReader();
        }
        public void DBReaderClose()
        {
            cmd = null;
            dr.Close();
            cn.Close();
        }



        public int DBReaderOpen1(string query)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            x = Convert.ToInt32(cmd.ExecuteScalar());
            return x;
        }
        public void DBReaderClose1()
        {
            cmd = null;
            cn.Close();
        }



        public void activecard(string query)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            cmd.ExecuteNonQuery();
        }



        public void DBDataAdapter(string query,string datafillname)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds,datafillname);

            //gvControl.DataSource = ds;
           //gvControl.DataBind();
           //DBClose();
        }
        public void DBDataAdapterClose()
        {
            cmd = null;
            cn.Close();
        }

        public void DBDataAdapterdropdown(string query, DropDownList ddlControl)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            ddlControl.DataSource = ds;
            ddlControl.DataTextField = "dept_name";
            ddlControl.DataValueField = "dept_id";
            ddlControl.DataBind();
            DBClose();
        }

        public void DBDataAdapterdropdowncourse(string query, DropDownList ddlControl)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            ddlControl.DataSource = ds;
            ddlControl.DataTextField = "course_name";
            ddlControl.DataValueField = "course_id";
            ddlControl.DataBind();
            DBClose();
        }
        public void DBDataAdapterdropdown_all(string query, DropDownList ddlControl)
        {
            DBOpen();
            cmd = new SqlCommand(query, cn);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            ddlControl.DataSource = ds;
            
        }
        public void DBDataAdapterdropdownclose_all()
        {
            DBClose();
        }
    }
}